# My Labymod Addon

## Overview
This is a Labymod addon that sends a welcome message to players when they join the server. The message includes the player's username and the server name.

## Features
- Sends a welcome message to players upon joining.
- Customizable server name in the configuration.

## Installation
1. Download the addon.
2. Place the addon folder in the `labymod/addons` directory.
3. Launch Labymod and enable the addon in the settings.

## Usage
Once the addon is installed and enabled, it will automatically send a welcome message to players when they join the server.

## Configuration
You can customize the server name in the `addon.json` file located in the `src/resources` directory.

## License
This project is licensed under the MIT License. See the LICENSE file for more details.