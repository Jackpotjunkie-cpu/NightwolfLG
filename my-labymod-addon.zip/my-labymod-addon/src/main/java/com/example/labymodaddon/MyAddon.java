package com.example.labymodaddon;

import com.example.labymodaddon.events.PlayerJoinEvent;
import net.labymod.api.LabyModAddon;
import net.labymod.api.event.EventManager;

public class MyAddon extends LabyModAddon {

    @Override
    public void onEnable() {
        EventManager.register(new PlayerJoinEvent());
    }

    @Override
    public void onDisable() {
        // Cleanup code if necessary
    }
}