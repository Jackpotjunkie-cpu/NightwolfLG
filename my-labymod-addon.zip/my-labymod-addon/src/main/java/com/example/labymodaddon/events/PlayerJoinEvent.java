package com.example.labymodaddon.events;

import net.labymod.api.event.player.PlayerJoinEvent;
import net.labymod.api.listener.EventListener;
import net.labymod.api.LabyMod;

public class PlayerJoinEventListener implements EventListener {

    @Override
    public void onPlayerJoin(PlayerJoinEvent event) {
        String username = event.getPlayer().getName();
        String serverName = LabyMod.getInstance().getServerName();
        event.getPlayer().sendMessage("Welcome " + username + " on " + serverName);
    }
}